import { useState, useCallback, useRef } from 'react'
import {
  BarChart3, Zap, RefreshCw, AlertCircle, ArrowLeft,
  ChevronRight, X, Copy, Scissors, FileText, RotateCcw,
  Minus, Plus, Info, Upload, ImageIcon, Camera,
  CheckCircle2, Eye
} from 'lucide-react'

// ─────────────────────────────────────────────────────────────
// CONFIG  (set VITE_ANTHROPIC_API_KEY in your .env file)
// ─────────────────────────────────────────────────────────────
const API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY || ''
const MODEL   = 'claude-sonnet-4-20250514'

const COUNTRIES = [
  { code: 'ng', name: 'Nigeria',  flag: '🇳🇬' },
  { code: 'ke', name: 'Kenya',    flag: '🇰🇪' },
  { code: 'tz', name: 'Tanzania', flag: '🇹🇿' },
  { code: 'gh', name: 'Ghana',    flag: '🇬🇭' },
  { code: 'ug', name: 'Uganda',   flag: '🇺🇬' },
  { code: 'zm', name: 'Zambia',   flag: '🇿🇲' },
  { code: 'cm', name: 'Cameroon', flag: '🇨🇲' },
]

const sleep = ms => new Promise(r => setTimeout(r, ms))

// ─────────────────────────────────────────────────────────────
// SPORTYBET BOOKING CODE API  (works locally — no CORS issues)
// ─────────────────────────────────────────────────────────────
async function decodeBookingCode(code, countryCode) {
  const url = `https://www.sportybet.com/api/${countryCode}/factsCenter/publicShareMatchList?bookingCode=${code.trim().toUpperCase()}`
  const res  = await fetch(url)
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  const json = await res.json()
  const list = json?.data?.list || json?.data?.matchList || []
  if (!list.length) throw new Error('Empty response')
  return list.map((m, i) => ({
    id:             `api_${i}`,
    home:           m.homeTeamName || 'Home',
    away:           m.awayTeamName || 'Away',
    league:         m.tournamentName || 'Unknown',
    selectedMarket: m.outCome?.[0]?.marketName  || '1X2',
    selectedPick:   m.outCome?.[0]?.outcomeName || 'Home',
    bookedOdds:     parseFloat(m.outCome?.[0]?.oddValue || 1.5).toFixed(2),
    status:         'Pre-match',
  }))
}

// ─────────────────────────────────────────────────────────────
// IMAGE → MATCHES  (Claude Vision)
// ─────────────────────────────────────────────────────────────
async function extractFromImage(base64Data, mimeType) {
  const prompt = `You are reading a SportyBet bet slip screenshot.
Extract EVERY match shown. Return ONLY a raw JSON array — no markdown, no backticks, nothing else before or after:
[{"home":"Team Name","away":"Team Name","league":"League name or Unknown","selectedMarket":"e.g. 1X2 or Over/Under 2.5 or BTTS etc","selectedPick":"e.g. Home Win or Over 2.5 or Yes etc","bookedOdds":"e.g. 2.10"}]

If you cannot read something clearly, make your best guess. Never return an empty array if there are visible matches.`

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method:  'POST',
    headers: {
      'Content-Type':      'application/json',
      'x-api-key':         API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model:      MODEL,
      max_tokens: 1000,
      messages: [{
        role:    'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: mimeType, data: base64Data } },
          { type: 'text',  text: prompt },
        ],
      }],
    }),
  })
  if (!res.ok) throw new Error(`API ${res.status}`)
  const data = await res.json()
  const raw  = data.content?.map(b => b.text || '').join('') || ''
  const m    = raw.match(/\[[\s\S]*\]/)
  if (!m) throw new Error('No matches found in image')
  return JSON.parse(m[0]).map((x, i) => ({ id: `img_${i}`, status: 'Pre-match', ...x }))
}

// ─────────────────────────────────────────────────────────────
// TEXT → MATCHES  (Claude Text)
// ─────────────────────────────────────────────────────────────
async function extractFromText(text) {
  const prompt = `Extract all football matches from this betting slip text.
Return ONLY a raw JSON array — no markdown, no backticks:
[{"home":"Team","away":"Team","league":"League or Unknown","selectedMarket":"market","selectedPick":"selection","bookedOdds":"2.10"}]

Slip:
${text}`

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method:  'POST',
    headers: {
      'Content-Type':      'application/json',
      'x-api-key':         API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model:      MODEL,
      max_tokens: 800,
      messages: [{ role: 'user', content: prompt }],
    }),
  })
  if (!res.ok) throw new Error(`API ${res.status}`)
  const data = await res.json()
  const raw  = data.content?.map(b => b.text || '').join('') || ''
  const m    = raw.match(/\[[\s\S]*\]/)
  if (!m) throw new Error('No matches found')
  return JSON.parse(m[0]).map((x, i) => ({ id: `txt_${i}`, status: 'Pre-match', ...x }))
}

// ─────────────────────────────────────────────────────────────
// SINGLE MATCH PREDICTION
// ─────────────────────────────────────────────────────────────
async function predictMatch(match) {
  const prompt = `Football AI analyst. Predict using Poisson, ELO, and xG models.
MATCH: ${match.home} vs ${match.away} | LEAGUE: ${match.league}
BOOKED: ${match.selectedPick} on ${match.selectedMarket} @ ${match.bookedOdds}

Return ONLY valid JSON:
{"confidence":72,"homeWinProb":52,"drawProb":26,"awayWinProb":22,"over25Prob":61,"bttsProb":54,"verdict":"Value","verdictReason":"brief reason","betterPick":"Over 2.5","betterMarket":"Goals Over/Under","betterOdds":"1.80","risk":"Medium","aiOdds":"1.90","expectedValue":0.08}`

  for (let i = 1; i <= 3; i++) {
    try {
      if (i > 1) await sleep(2000 * i)
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method:  'POST',
        headers: {
          'Content-Type':      'application/json',
          'x-api-key':         API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model:      MODEL,
          max_tokens: 350,
          messages: [{ role: 'user', content: prompt }],
        }),
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      const raw  = data.content?.map(b => b.text || '').join('') || ''
      const m    = raw.match(/\{[\s\S]*\}/)
      if (!m) throw new Error('No JSON')
      return JSON.parse(m[0])
    } catch (e) {
      if (i === 3) return { confidence: 50, verdict: 'Fair', verdictReason: 'Analysis incomplete — retry', risk: 'Medium', homeWinProb: 40, drawProb: 30, awayWinProb: 30 }
    }
  }
}

// ─────────────────────────────────────────────────────────────
// COLOUR HELPERS
// ─────────────────────────────────────────────────────────────
const vcol = v => v === 'Value' ? '#00e676' : v === 'Fair' ? '#ffb300' : '#ff5252'
const rcol = r => r === 'Low'   ? '#00e676' : r === 'Medium' ? '#ffb300' : '#ff5252'
const ccol = c => +c >= 65      ? '#00e676' : +c >= 45 ? '#ffb300' : '#ff5252'

// ─────────────────────────────────────────────────────────────
// SUB-COMPONENTS
// ─────────────────────────────────────────────────────────────
function HealthBar({ score }) {
  const col = score >= 60 ? '#00e676' : score >= 35 ? '#ffb300' : '#ff5252'
  const lbl = score >= 70 ? 'Strong' : score >= 50 ? 'Moderate' : score >= 30 ? 'Risky' : 'Weak'
  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
        <span style={{ fontSize:9, color:'#666', textTransform:'uppercase', letterSpacing:'0.1em' }}>Slip Health</span>
        <span style={{ fontSize:11, fontWeight:700, color:col }}>{lbl} · {score}/100</span>
      </div>
      <div style={{ background:'rgba(255,255,255,0.07)', borderRadius:8, height:9, overflow:'hidden' }}>
        <div style={{ width:`${score}%`, height:'100%', background:col, borderRadius:8, transition:'width 1.8s ease' }} />
      </div>
    </div>
  )
}

function ProbBar({ label, val = 0, color = '#00e676' }) {
  return (
    <div style={{ background:'rgba(255,255,255,0.03)', borderRadius:8, padding:'7px 9px' }}>
      <div style={{ fontSize:9, color:'#555', marginBottom:3 }}>{label}</div>
      <div style={{ background:'rgba(255,255,255,0.06)', borderRadius:3, height:4, overflow:'hidden', marginBottom:4 }}>
        <div style={{ width:`${val}%`, height:'100%', background:color, borderRadius:3 }} />
      </div>
      <div style={{ fontSize:13, fontWeight:700, color:'#fff' }}>{val}%</div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────────────────
export default function App() {
  const [screen,      setScreen]      = useState('home')   // home | loading | results
  const [tab,         setTab]         = useState('image')  // image | text | code
  const [pastedText,  setPastedText]  = useState('')
  const [bookingCode, setBookingCode] = useState('')
  const [country,     setCountry]     = useState(COUNTRIES[0])
  const [imageFile,   setImageFile]   = useState(null)     // { name, preview, base64, mimeType }
  const [matches,     setMatches]     = useState([])
  const [preds,       setPreds]       = useState({})
  const [predLoading, setPredLoading] = useState({})
  const [allDone,     setAllDone]     = useState(false)
  const [loadingMsg,  setLoadingMsg]  = useState('')
  const [submitError, setSubmitError] = useState('')
  const [removed,     setRemoved]     = useState(new Set())
  const [expanded,    setExpanded]    = useState(null)
  const [source,      setSource]      = useState('')
  const fileRef = useRef(null)

  // ── derived ──
  const active      = matches.filter(m => !removed.has(m.id))
  const activePreds = active.map(m => preds[m.id]).filter(Boolean)
  const avgConf     = activePreds.length
    ? Math.round(activePreds.reduce((a, p) => a + (+p.confidence || 0), 0) / activePreds.length)
    : 0
  const health    = Math.max(0, Math.min(100, avgConf - Math.max(0, (active.length - 4) * 4)))
  const totalOdds = active.reduce((acc, m) => acc * parseFloat(m.bookedOdds || 1), 1).toFixed(2)
  const valueCt   = activePreds.filter(p => p.verdict === 'Value').length
  const skipCt    = activePreds.filter(p => p.verdict === 'Skip').length

  // ── batch predict ──
  const batchPredict = useCallback(async list => {
    setAllDone(false)
    for (const match of list) {
      setPredLoading(p => ({ ...p, [match.id]: true }))
      const pred = await predictMatch(match)
      setPreds(p => ({ ...p, [match.id]: pred }))
      setPredLoading(p => ({ ...p, [match.id]: false }))
      await sleep(400)
    }
    setAllDone(true)
  }, [])

  // ── handle file pick ──
  const handleFileChange = e => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = evt => {
      const dataUrl  = evt.target.result
      const base64   = dataUrl.split(',')[1]
      const mimeType = file.type || 'image/jpeg'
      setImageFile({ name: file.name, preview: dataUrl, base64, mimeType })
      setSubmitError('')
    }
    reader.readAsDataURL(file)
  }

  // ── submit ──
  const handleSubmit = async () => {
    if (!API_KEY) {
      setSubmitError('No API key found. Add VITE_ANTHROPIC_API_KEY=your_key to your .env file and restart.')
      return
    }
    setSubmitError('')

    try {
      if (tab === 'image') {
        if (!imageFile) { setSubmitError('Please upload a screenshot first.'); return }
        setScreen('loading')
        setLoadingMsg('Claude Vision reading your slip screenshot…')
        const extracted = await extractFromImage(imageFile.base64, imageFile.mimeType)
        if (!extracted.length) throw new Error('No matches found in image')
        finishExtract(extracted, `Screenshot: ${imageFile.name}`)
      }

      else if (tab === 'text') {
        if (!pastedText.trim()) { setSubmitError('Please paste your slip text first.'); return }
        setScreen('loading')
        setLoadingMsg('AI reading your slip text…')
        const extracted = await extractFromText(pastedText)
        if (!extracted.length) throw new Error('No matches found in text')
        finishExtract(extracted, 'Extracted from pasted text')
      }

      else {
        // Booking code — works locally without CORS issues
        if (!bookingCode.trim()) { setSubmitError('Enter your SportyBet booking code.'); return }
        setScreen('loading')
        setLoadingMsg(`Decoding ${bookingCode.toUpperCase()} via SportyBet API…`)
        const extracted = await decodeBookingCode(bookingCode, country.code)
        finishExtract(extracted, `Booking code: ${bookingCode.toUpperCase()} · ${country.flag} ${country.name}`)
      }
    } catch (err) {
      setScreen('home')
      setSubmitError(err.message || 'Something went wrong. Please try again.')
    }
  }

  const finishExtract = (list, src) => {
    setMatches(list)
    setSource(src)
    setRemoved(new Set())
    setPreds({})
    setExpanded(null)
    setScreen('results')
    batchPredict(list)
  }

  const removeWeak = () => {
    const ids = matches
      .filter(m => { const p = preds[m.id]; return p && (p.verdict === 'Skip' || +p.confidence < 45) })
      .map(m => m.id)
    setRemoved(prev => new Set([...prev, ...ids]))
  }

  const resetAll = () => {
    setScreen('home'); setMatches([]); setPreds({}); setRemoved(new Set())
    setExpanded(null); setSubmitError(''); setBookingCode('')
    setPastedText(''); setImageFile(null); setAllDone(false)
  }

  // ─────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight:'100vh', background:'#070c09', color:'#fff', fontFamily:"'Space Grotesk',sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Bebas+Neue&display=swap" rel="stylesheet" />

      {/* HEADER */}
      <div style={{ background:'rgba(0,230,118,0.04)', borderBottom:'1px solid rgba(0,230,118,0.1)', padding:'0.75rem 1rem', position:'sticky', top:0, zIndex:60 }}>
        <div style={{ maxWidth:720, margin:'0 auto', display:'flex', alignItems:'center', gap:10 }}>
          {screen !== 'home' && (
            <button onClick={resetAll} style={{ background:'rgba(255,255,255,0.05)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:7, padding:'5px 9px', color:'#666', fontFamily:'inherit', display:'flex', alignItems:'center', gap:3, fontSize:11 }}>
              <ArrowLeft size={12} /> Back
            </button>
          )}
          <div style={{ display:'flex', alignItems:'center', gap:9, flex:1 }}>
            <div style={{ width:30, height:30, borderRadius:8, background:'linear-gradient(135deg,#00e676,#00c853)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <BarChart3 size={15} color="#000" strokeWidth={2.5} />
            </div>
            <div>
              <div style={{ fontFamily:"'Bebas Neue'", fontSize:17, letterSpacing:'0.1em', lineHeight:1 }}>
                SlipIQ <span style={{ color:'#00e676' }}>AI</span>
              </div>
              <div style={{ fontSize:8, color:'#00c853', letterSpacing:'0.13em', textTransform:'uppercase' }}>
                SportyBet Slip Intelligence Engine
              </div>
            </div>
          </div>
          {screen === 'results' && active.length > 0 && (
            <div style={{ fontSize:13, color:'#ffb300', fontWeight:700 }}>@ {totalOdds}</div>
          )}
        </div>
      </div>

      <div style={{ maxWidth:720, margin:'0 auto', padding:'1rem' }}>

        {/* ══ HOME ══════════════════════════════════════════════ */}
        {screen === 'home' && (
          <div className="slide-up">
            {/* Hero */}
            <div style={{ textAlign:'center', padding:'1.2rem 0 1rem' }}>
              <div style={{ fontSize:44, marginBottom:10 }}>🎫</div>
              <div style={{ fontFamily:"'Bebas Neue'", fontSize:28, letterSpacing:'0.06em', lineHeight:1.15, marginBottom:8 }}>
                SCREENSHOT IT.<br />
                <span style={{ color:'#00e676' }}>WE ANALYSE IT.</span>
              </div>
              <p style={{ fontSize:12, color:'#555', maxWidth:400, margin:'0 auto', lineHeight:1.7 }}>
                Take a screenshot of your SportyBet slip, upload it here.
                SlipIQ reads every match, AI-scores each leg, and surgically
                rebuilds your slip for maximum value.
              </p>
            </div>

            {/* TAB BAR */}
            <div style={{ display:'flex', background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.07)', borderRadius:13, padding:4, marginBottom:18, gap:4 }}>
              {[
                { id:'image', icon:<Camera size={13} />,   label:'Upload Screenshot', badge:'New' },
                { id:'text',  icon:<FileText size={13} />, label:'Paste Text',         badge:null  },
                { id:'code',  icon:<Copy size={13} />,     label:'Booking Code',       badge:null  },
              ].map(({ id, icon, label, badge }) => (
                <button key={id} onClick={() => { setTab(id); setSubmitError('') }}
                  style={{ flex:1, padding:'9px 6px', borderRadius:10, border:'none', background: tab === id ? '#00e676' : 'transparent', color: tab === id ? '#000' : '#555', fontWeight: tab === id ? 700 : 400, fontSize:11, fontFamily:'inherit', display:'flex', alignItems:'center', justifyContent:'center', gap:5, transition:'all 0.18s' }}>
                  {icon} {label}
                  {badge && tab === id && (
                    <span style={{ fontSize:8, background:'rgba(0,0,0,0.2)', borderRadius:8, padding:'1px 5px' }}>{badge}</span>
                  )}
                </button>
              ))}
            </div>

            {/* ── IMAGE TAB ── */}
            {tab === 'image' && (
              <div>
                <input ref={fileRef} type="file" accept="image/*" style={{ display:'none' }} onChange={handleFileChange} />

                {!imageFile ? (
                  // Drop zone
                  <div
                    onClick={() => fileRef.current?.click()}
                    style={{ border:'2px dashed rgba(0,230,118,0.25)', borderRadius:16, padding:'2.5rem 1rem', textAlign:'center', cursor:'pointer', background:'rgba(0,230,118,0.03)', transition:'all 0.2s', marginBottom:14 }}
                    onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(0,230,118,0.5)'; e.currentTarget.style.background = 'rgba(0,230,118,0.06)' }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(0,230,118,0.25)'; e.currentTarget.style.background = 'rgba(0,230,118,0.03)' }}
                  >
                    <div style={{ width:56, height:56, borderRadius:14, background:'rgba(0,230,118,0.1)', border:'1px solid rgba(0,230,118,0.2)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px' }}>
                      <Upload size={24} color="#00e676" />
                    </div>
                    <div style={{ fontWeight:700, fontSize:15, marginBottom:6 }}>Tap to upload screenshot</div>
                    <div style={{ fontSize:12, color:'#555', lineHeight:1.7 }}>
                      Take a screenshot of your SportyBet slip<br />
                      Upload it here — Claude Vision reads it automatically<br />
                      <span style={{ color:'#00e676', fontSize:11 }}>JPG · PNG · WebP · any image format</span>
                    </div>
                  </div>
                ) : (
                  // Preview
                  <div style={{ marginBottom:14 }}>
                    <div style={{ position:'relative', borderRadius:14, overflow:'hidden', border:'1px solid rgba(0,230,118,0.25)', marginBottom:10 }}>
                      <img src={imageFile.preview} alt="Slip screenshot" style={{ width:'100%', maxHeight:320, objectFit:'contain', background:'#0a1a0d', display:'block' }} />
                      <div style={{ position:'absolute', top:8, right:8, display:'flex', gap:6 }}>
                        <button onClick={() => fileRef.current?.click()} style={{ background:'rgba(0,0,0,0.75)', border:'1px solid rgba(255,255,255,0.15)', borderRadius:7, padding:'5px 10px', color:'#fff', fontSize:11, fontFamily:'inherit', display:'flex', alignItems:'center', gap:4 }}>
                          <RefreshCw size={11} /> Change
                        </button>
                        <button onClick={() => setImageFile(null)} style={{ background:'rgba(255,82,82,0.8)', border:'none', borderRadius:7, padding:'5px 8px', color:'#fff', fontFamily:'inherit', display:'flex', alignItems:'center' }}>
                          <X size={11} />
                        </button>
                      </div>
                    </div>
                    <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 12px', background:'rgba(0,230,118,0.06)', border:'1px solid rgba(0,230,118,0.18)', borderRadius:9, fontSize:12 }}>
                      <CheckCircle2 size={14} color="#00e676" />
                      <span style={{ color:'#00e676', fontWeight:600 }}>Screenshot ready</span>
                      <span style={{ color:'#555' }}>— {imageFile.name}</span>
                    </div>
                  </div>
                )}

                <div style={{ background:'rgba(255,179,0,0.05)', border:'1px solid rgba(255,179,0,0.12)', borderRadius:10, padding:'10px 13px', marginBottom:14, fontSize:11, color:'#777', lineHeight:1.6, display:'flex', gap:8 }}>
                  <Info size={13} color="#ffb300" style={{ flexShrink:0, marginTop:1 }} />
                  <div>
                    <b style={{ color:'#ffb300' }}>How to get a screenshot:</b> Open SportyBet app → tap your bet slip → take screenshot with your phone's power + volume button. Upload it here.
                  </div>
                </div>
              </div>
            )}

            {/* ── TEXT TAB ── */}
            {tab === 'text' && (
              <div>
                <div style={{ fontSize:10, color:'#555', textTransform:'uppercase', letterSpacing:'0.12em', marginBottom:7 }}>Paste your slip text — any format</div>
                <textarea
                  value={pastedText}
                  onChange={e => { setPastedText(e.target.value); setSubmitError('') }}
                  rows={9}
                  placeholder={'Paste anything, for example:\n\nMan United vs Arsenal — Home Win — 2.10\nOver 2.5 Goals — Chelsea vs Liverpool — 1.75\nBTTS Yes — Barcelona vs Real Madrid — 1.90\nKano Pillars vs Enyimba — 1X — 3.20\n\nCopy from WhatsApp, emails, anywhere — AI reads it.'}
                  style={{ width:'100%', background:'rgba(255,255,255,0.03)', border:`1px solid ${pastedText ? 'rgba(0,230,118,0.25)' : 'rgba(255,255,255,0.09)'}`, borderRadius:12, padding:'13px 14px', color:'#fff', fontSize:13, outline:'none', fontFamily:'inherit', resize:'none', lineHeight:1.7, transition:'border-color 0.2s', marginBottom:14 }}
                />
              </div>
            )}

            {/* ── CODE TAB ── */}
            {tab === 'code' && (
              <div>
                <div style={{ fontSize:10, color:'#555', textTransform:'uppercase', letterSpacing:'0.12em', marginBottom:7 }}>SportyBet Booking Code</div>
                <input
                  value={bookingCode}
                  onChange={e => { setBookingCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '')); setSubmitError('') }}
                  onKeyDown={e => e.key === 'Enter' && handleSubmit()}
                  placeholder="e.g.  A1B2C3"
                  maxLength={12}
                  style={{ width:'100%', background:'rgba(0,230,118,0.04)', border:`2px solid ${bookingCode ? 'rgba(0,230,118,0.35)' : 'rgba(255,255,255,0.1)'}`, borderRadius:12, padding:'14px 16px', color:'#fff', fontSize:22, fontWeight:700, outline:'none', fontFamily:"'Bebas Neue'", letterSpacing:'0.2em', textAlign:'center', transition:'border-color 0.2s', marginBottom:12 }}
                />
                <div style={{ marginBottom:10 }}>
                  <div style={{ fontSize:10, color:'#555', textTransform:'uppercase', letterSpacing:'0.12em', marginBottom:8 }}>Country</div>
                  <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
                    {COUNTRIES.map(c => (
                      <button key={c.code} onClick={() => setCountry(c)}
                        style={{ padding:'5px 11px', borderRadius:20, border:`1px solid ${country.code === c.code ? 'rgba(0,230,118,0.45)' : 'rgba(255,255,255,0.07)'}`, background: country.code === c.code ? 'rgba(0,230,118,0.1)' : 'rgba(255,255,255,0.02)', color: country.code === c.code ? '#00e676' : '#666', fontSize:11, fontWeight: country.code === c.code ? 700 : 400, fontFamily:'inherit' }}>
                        {c.flag} {c.name}
                      </button>
                    ))}
                  </div>
                </div>
                <div style={{ background:'rgba(0,230,118,0.05)', border:'1px solid rgba(0,230,118,0.15)', borderRadius:10, padding:'10px 13px', marginBottom:14, fontSize:11, color:'#777', lineHeight:1.6, display:'flex', gap:8 }}>
                  <CheckCircle2 size={13} color="#00e676" style={{ flexShrink:0, marginTop:1 }} />
                  <div>
                    <b style={{ color:'#00e676' }}>Booking codes work perfectly when hosted locally.</b><br />
                    No CORS issues — direct API handshake with SportyBet.
                  </div>
                </div>
              </div>
            )}

            {/* ERROR */}
            {submitError && (
              <div style={{ display:'flex', gap:9, alignItems:'flex-start', background:'rgba(255,82,82,0.07)', border:'1px solid rgba(255,82,82,0.2)', borderRadius:10, padding:'11px 13px', marginBottom:14, fontSize:12, color:'#ff8a80', lineHeight:1.6 }}>
                <AlertCircle size={14} color="#ff5252" style={{ flexShrink:0, marginTop:1 }} />
                <span>{submitError}</span>
              </div>
            )}

            {/* SUBMIT */}
            <button onClick={handleSubmit}
              style={{ width:'100%', padding:'14px', borderRadius:12, border:'none', background:'linear-gradient(135deg,#00e676,#00c853)', color:'#000', fontWeight:700, fontSize:14, fontFamily:'inherit', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
              <Zap size={16} />
              {tab === 'image' ? 'Analyse Screenshot' : tab === 'text' ? 'Extract & Analyse Matches' : 'Decode Booking Code'}
            </button>

            <div style={{ display:'flex', flexWrap:'wrap', gap:6, justifyContent:'center', marginTop:16 }}>
              {['📸 Screenshot reading','AI Slip extraction','Leg-by-leg scoring','Slip Surgery','Value detector','Better market AI'].map(f => (
                <span key={f} style={{ fontSize:10, padding:'3px 9px', borderRadius:20, background:'rgba(0,230,118,0.06)', color:'#00e676', border:'1px solid rgba(0,230,118,0.12)' }}>{f}</span>
              ))}
            </div>
          </div>
        )}

        {/* ══ LOADING ════════════════════════════════════════════ */}
        {screen === 'loading' && (
          <div style={{ textAlign:'center', padding:'4rem 1rem' }} className="slide-up">
            <div style={{ width:52, height:52, border:'3px solid rgba(0,230,118,0.12)', borderTopColor:'#00e676', borderRadius:'50%', margin:'0 auto 18px' }} className="spin" />
            <div style={{ fontFamily:"'Bebas Neue'", fontSize:22, letterSpacing:'0.08em', marginBottom:7 }}>
              {tab === 'image' ? 'CLAUDE VISION READING SCREENSHOT' : tab === 'code' ? 'HANDSHAKING WITH SPORTYBET' : 'AI EXTRACTING MATCHES'}
            </div>
            <div style={{ fontSize:13, color:'#00e676' }} className="pulse">{loadingMsg}</div>
            <div style={{ marginTop:18 }}>
              {(tab === 'image'
                ? ['Scanning screenshot pixels…','Identifying team names…','Reading markets & odds…','Building match list…']
                : tab === 'text'
                ? ['Parsing slip text…','Identifying teams & leagues…','Extracting markets & odds…','Preparing batch analysis…']
                : ['Connecting to SportyBet…','Decoding booking code…','Pulling match list…','Preparing AI engine…']
              ).map((s, i) => (
                <div key={i} style={{ fontSize:10, color:'#1a2a1a', marginTop:4 }}>• {s}</div>
              ))}
            </div>
          </div>
        )}

        {/* ══ RESULTS ═══════════════════════════════════════════ */}
        {screen === 'results' && (
          <div className="slide-up">

            {/* DASHBOARD */}
            <div style={{ background:'rgba(0,230,118,0.04)', border:'1px solid rgba(0,230,118,0.14)', borderRadius:16, padding:'1.2rem', marginBottom:12 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
                <div>
                  <div style={{ fontFamily:"'Bebas Neue'", fontSize:18, letterSpacing:'0.06em' }}>SLIP INTELLIGENCE REPORT</div>
                  <div style={{ fontSize:10, color:'#555', marginTop:2 }}>{source}</div>
                </div>
                <div style={{ textAlign:'right' }}>
                  <div style={{ fontFamily:"'Bebas Neue'", fontSize:24, color:'#ffb300', letterSpacing:'0.06em' }}>@ {totalOdds}</div>
                  <div style={{ fontSize:9, color:'#555' }}>{active.length} legs · {matches.length} total</div>
                </div>
              </div>

              <HealthBar score={health} />

              <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:7, marginTop:11 }}>
                {[
                  { l:'Total',   v: matches.length,              c:'#fff'       },
                  { l:'Value ✓', v: valueCt,                     c:'#00e676'    },
                  { l:'Skip ✗',  v: skipCt,                      c:'#ff5252'    },
                  { l:'Avg Conf',v: allDone ? avgConf+'%' : '…', c: ccol(avgConf) },
                ].map(({ l, v, c }) => (
                  <div key={l} style={{ background:'rgba(255,255,255,0.03)', borderRadius:9, padding:'8px', textAlign:'center' }}>
                    <div style={{ fontWeight:700, fontSize:16, color:c }}>{v}</div>
                    <div style={{ fontSize:8, color:'#444', textTransform:'uppercase', letterSpacing:'0.08em', marginTop:2 }}>{l}</div>
                  </div>
                ))}
              </div>

              {allDone && skipCt > 0 && (
                <button onClick={removeWeak}
                  style={{ width:'100%', marginTop:11, padding:'10px', borderRadius:9, border:'1px solid rgba(255,82,82,0.25)', background:'rgba(255,82,82,0.06)', color:'#ff8a80', fontSize:11, fontWeight:700, fontFamily:'inherit', display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
                  <Scissors size={13} /> Slip Surgery — Remove {skipCt} Weak Leg{skipCt > 1 ? 's' : ''}
                </button>
              )}
              {removed.size > 0 && (
                <button onClick={() => setRemoved(new Set())}
                  style={{ width:'100%', marginTop:7, padding:'7px', borderRadius:8, border:'1px solid rgba(255,255,255,0.06)', background:'transparent', color:'#444', fontSize:10, fontFamily:'inherit', display:'flex', alignItems:'center', justifyContent:'center', gap:5 }}>
                  <RotateCcw size={11} /> Restore {removed.size} removed leg{removed.size > 1 ? 's' : ''}
                </button>
              )}
            </div>

            {/* Progress banner */}
            {!allDone && (
              <div style={{ background:'rgba(0,230,118,0.03)', border:'1px solid rgba(0,230,118,0.1)', borderRadius:9, padding:'9px 13px', marginBottom:11, display:'flex', alignItems:'center', gap:9 }}>
                <div style={{ width:12, height:12, border:'2px solid rgba(0,230,118,0.15)', borderTopColor:'#00e676', borderRadius:'50%' }} className="spin" />
                <div style={{ fontSize:11, color:'#00e676' }}>
                  AI analysing… {Object.keys(preds).length} / {matches.length} done
                </div>
              </div>
            )}

            {/* MATCH CARDS */}
            <div style={{ display:'flex', flexDirection:'column', gap:7 }}>
              {matches.map(match => {
                const pred    = preds[match.id]
                const loading = predLoading[match.id]
                const isOut   = removed.has(match.id)
                const isOpen  = expanded === match.id
                const verdict = pred?.verdict
                const vc_     = verdict ? vcol(verdict) : '#2a2a2a'

                return (
                  <div key={match.id} style={{ background: isOut ? 'rgba(255,82,82,0.03)' : 'rgba(255,255,255,0.025)', border:`1px solid ${isOut ? 'rgba(255,82,82,0.18)' : verdict === 'Value' ? 'rgba(0,230,118,0.18)' : verdict === 'Skip' ? 'rgba(255,82,82,0.13)' : 'rgba(255,255,255,0.07)'}`, borderRadius:13, overflow:'hidden', opacity: isOut ? 0.45 : 1, transition:'all 0.25s' }}>

                    {/* Row */}
                    <div onClick={() => setExpanded(isOpen ? null : match.id)}
                      style={{ padding:'12px 13px', cursor:'pointer', display:'flex', alignItems:'center', gap:9 }}>

                      <div style={{ width:7, height:7, borderRadius:'50%', background: loading ? '#ffb300' : (pred ? vc_ : '#2a2a2a'), flexShrink:0 }} className={loading ? 'pulse' : ''} />

                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontWeight:600, fontSize:13, display:'flex', alignItems:'baseline', gap:5, flexWrap:'wrap' }}>
                          <span style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', maxWidth:130 }}>{match.home}</span>
                          <span style={{ color:'#333', fontSize:10, flexShrink:0 }}>vs</span>
                          <span style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', maxWidth:130 }}>{match.away}</span>
                        </div>
                        <div style={{ fontSize:10, color:'#555', marginTop:2, display:'flex', gap:8, flexWrap:'wrap' }}>
                          <span>{match.league}</span>
                          <span style={{ color:'#ffb300', fontWeight:600 }}>{match.selectedPick} @ {match.bookedOdds}</span>
                        </div>
                      </div>

                      <div style={{ display:'flex', alignItems:'center', gap:7, flexShrink:0 }}>
                        {loading && <div style={{ width:13, height:13, border:'2px solid rgba(0,230,118,0.15)', borderTopColor:'#00e676', borderRadius:'50%' }} className="spin" />}
                        {pred && !loading && (
                          <>
                            <div style={{ textAlign:'center' }}>
                              <div style={{ fontWeight:800, fontSize:15, color:ccol(pred.confidence) }}>{pred.confidence}%</div>
                              <div style={{ fontSize:8, color:'#444', textTransform:'uppercase' }}>Conf</div>
                            </div>
                            <span style={{ fontSize:9, fontWeight:700, padding:'3px 7px', borderRadius:20, background:`${vc_}18`, color:vc_, border:`1px solid ${vc_}33`, whiteSpace:'nowrap' }}>
                              {verdict}
                            </span>
                          </>
                        )}
                        <button onClick={e => { e.stopPropagation(); setRemoved(prev => { const n = new Set(prev); isOut ? n.delete(match.id) : n.add(match.id); return n }) }}
                          style={{ background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.07)', borderRadius:6, padding:'4px 6px', color: isOut ? '#00e676' : '#ff5252', display:'flex' }}>
                          {isOut ? <Plus size={11} /> : <Minus size={11} />}
                        </button>
                        <ChevronRight size={12} color="#2a2a2a" style={{ transform: isOpen ? 'rotate(90deg)' : 'none', transition:'transform 0.18s' }} />
                      </div>
                    </div>

                    {/* Expanded */}
                    {isOpen && pred && (
                      <div style={{ borderTop:'1px solid rgba(255,255,255,0.05)', padding:'12px 13px', background:'rgba(0,0,0,0.18)' }}>
                        <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:6, marginBottom:11 }}>
                          <ProbBar label={`${match.home} W`} val={pred.homeWinProb} color="#00e676" />
                          <ProbBar label="Draw"              val={pred.drawProb}     color="#ffb300" />
                          <ProbBar label={`${match.away} W`} val={pred.awayWinProb}  color="#ff6b35" />
                          <ProbBar label="Ov 2.5"            val={pred.over25Prob}   color="#2979ff" />
                          <ProbBar label="BTTS"              val={pred.bttsProb}     color="#7c4dff" />
                        </div>

                        <div style={{ background:`${vc_}0e`, border:`1px solid ${vc_}2a`, borderRadius:9, padding:'9px 11px', marginBottom:9 }}>
                          <div style={{ fontSize:9, color:vc_, fontWeight:700, textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:3 }}>
                            {verdict === 'Value' ? '✓ Value Bet' : verdict === 'Skip' ? '✗ Consider Removing' : '~ Fair Price'}
                          </div>
                          <div style={{ fontSize:12, color:'#aaa', lineHeight:1.6 }}>{pred.verdictReason}</div>
                        </div>

                        {pred.betterPick && pred.betterPick !== match.selectedPick && (
                          <div style={{ background:'rgba(0,230,118,0.05)', border:'1px solid rgba(0,230,118,0.15)', borderRadius:9, padding:'9px 11px', marginBottom:9 }}>
                            <div style={{ fontSize:9, color:'#00e676', fontWeight:700, textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:5 }}>💡 Better Market</div>
                            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                              <div>
                                <div style={{ fontSize:12, color:'#fff', fontWeight:600 }}>{pred.betterPick}</div>
                                <div style={{ fontSize:10, color:'#555' }}>{pred.betterMarket}</div>
                              </div>
                              <div style={{ fontWeight:700, fontSize:14, color:'#ffb300' }}>@ {pred.betterOdds}</div>
                            </div>
                          </div>
                        )}

                        <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                          {pred.risk && <span style={{ fontSize:9, fontWeight:700, padding:'3px 8px', borderRadius:20, background:`${rcol(pred.risk)}15`, color:rcol(pred.risk), border:`1px solid ${rcol(pred.risk)}30` }}>Risk: {pred.risk}</span>}
                          {pred.aiOdds && <span style={{ fontSize:9, padding:'3px 8px', borderRadius:20, background:'rgba(255,179,0,0.08)', color:'#ffb300', border:'1px solid rgba(255,179,0,0.2)' }}>Fair Odds: {pred.aiOdds}</span>}
                          {pred.expectedValue != null && (
                            <span style={{ fontSize:9, fontWeight:700, padding:'3px 8px', borderRadius:20, background: pred.expectedValue >= 0 ? 'rgba(0,230,118,0.08)' : 'rgba(255,82,82,0.08)', color: pred.expectedValue >= 0 ? '#00e676' : '#ff5252', border:`1px solid ${pred.expectedValue >= 0 ? 'rgba(0,230,118,0.2)' : 'rgba(255,82,82,0.2)'}` }}>
                              EV: {pred.expectedValue >= 0 ? '+' : ''}{pred.expectedValue}
                            </span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>

            {/* Removed summary */}
            {removed.size > 0 && (
              <div style={{ background:'rgba(255,82,82,0.04)', border:'1px solid rgba(255,82,82,0.12)', borderRadius:11, padding:'0.9rem', marginTop:10 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:9 }}>
                  <div style={{ fontSize:10, color:'#ff8a80', fontWeight:700, textTransform:'uppercase', letterSpacing:'0.1em', display:'flex', alignItems:'center', gap:5 }}>
                    <Scissors size={11} /> Removed ({removed.size} legs)
                  </div>
                  <div style={{ fontSize:12, fontWeight:700, color:'#ffb300' }}>New odds: @ {totalOdds}</div>
                </div>
                {matches.filter(m => removed.has(m.id)).map(m => (
                  <div key={m.id} style={{ display:'flex', alignItems:'center', gap:7, padding:'5px 0', borderBottom:'1px solid rgba(255,255,255,0.03)', fontSize:10, color:'#444' }}>
                    <X size={10} color="#ff5252" />
                    <span style={{ flex:1 }}>{m.home} vs {m.away}</span>
                    <span style={{ color:'#ff5252' }}>@ {m.bookedOdds}</span>
                  </div>
                ))}
              </div>
            )}

            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:7, marginTop:12 }}>
              <button onClick={resetAll} style={{ padding:'10px', borderRadius:9, border:'1px solid rgba(255,255,255,0.07)', background:'transparent', color:'#444', fontSize:11, fontFamily:'inherit', display:'flex', alignItems:'center', justifyContent:'center', gap:5 }}>
                <RotateCcw size={12} /> New Slip
              </button>
              <button onClick={() => batchPredict(matches)} disabled={!allDone}
                style={{ padding:'10px', borderRadius:9, border:'1px solid rgba(0,230,118,0.18)', background:'rgba(0,230,118,0.05)', color: allDone ? '#00e676' : '#333', fontSize:11, fontWeight:700, fontFamily:'inherit', display:'flex', alignItems:'center', justifyContent:'center', gap:5 }}>
                <RefreshCw size={12} /> Re-analyse All
              </button>
            </div>

            <div style={{ fontSize:8, color:'#151e15', textAlign:'center', paddingTop:11, marginTop:10, borderTop:'1px solid rgba(255,255,255,0.03)', lineHeight:1.7 }}>
              ⚠️ AI predictions are statistical models only — not guaranteed outcomes. Gamble responsibly. 18+
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
